/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.ArrayList;


public class Apostar {
    private double saldoTotal;
    private Caballo caballoGanador;
    private ArrayList<Jugador> jugadorGanador;
}
